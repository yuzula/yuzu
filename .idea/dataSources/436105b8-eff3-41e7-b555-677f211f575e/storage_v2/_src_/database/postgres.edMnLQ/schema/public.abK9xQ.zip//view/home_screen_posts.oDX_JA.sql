create view home_screen_posts
            (id, user_id, community_domain_name, content, is_private, is_deleted, created_at, updated_at, vote_count,
             comment_count, hotness, is_flagged, current_user_vote, username)
as
SELECT posts_with_hotness.id,
       posts_with_hotness.user_id,
       posts_with_hotness.community_domain_name,
       posts_with_hotness.content,
       posts_with_hotness.is_private,
       posts_with_hotness.is_deleted,
       posts_with_hotness.created_at,
       posts_with_hotness.updated_at,
       posts_with_hotness.vote_count,
       posts_with_hotness.comment_count,
       posts_with_hotness.hotness,
       COALESCE(reported_posts.is_flagged, false) AS is_flagged,
       CASE
           WHEN post_votes.is_upvote = true THEN 'upvote'::text
           WHEN post_votes.is_upvote = false THEN 'downvote'::text
           ELSE NULL::text
           END                                    AS current_user_vote,
       profiles.username
FROM posts_with_hotness
         LEFT JOIN reported_posts ON posts_with_hotness.id = reported_posts.post_id
         LEFT JOIN post_votes ON posts_with_hotness.id = post_votes.post_id AND auth.uid() = post_votes.user_id
         JOIN profiles ON posts_with_hotness.user_id = profiles.id;

alter table home_screen_posts
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on home_screen_posts to anon;

grant delete, insert, references, select, trigger, truncate, update on home_screen_posts to authenticated;

grant delete, insert, references, select, trigger, truncate, update on home_screen_posts to service_role;

