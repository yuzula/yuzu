create function count_posts_by_user(post_user_id uuid) returns integer
    stable
    language sql
as
$$
  select coalesce(count(id), 0)
  from posts
  where user_id = post_user_id;
$$;

alter function count_posts_by_user(uuid) owner to postgres;

grant execute on function count_posts_by_user(uuid) to anon;

grant execute on function count_posts_by_user(uuid) to authenticated;

grant execute on function count_posts_by_user(uuid) to service_role;

