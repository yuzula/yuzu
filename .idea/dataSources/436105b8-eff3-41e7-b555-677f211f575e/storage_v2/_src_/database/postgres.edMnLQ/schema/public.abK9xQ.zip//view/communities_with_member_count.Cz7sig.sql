create view communities_with_member_count(domain_name, created_at, member_count) as
SELECT communities.domain_name,
       communities.created_at,
       count(profiles.id) AS member_count
FROM communities
         LEFT JOIN profiles ON communities.domain_name = profiles.community_domain_name
GROUP BY communities.domain_name
ORDER BY (count(profiles.id));

alter table communities_with_member_count
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on communities_with_member_count to anon;

grant delete, insert, references, select, trigger, truncate, update on communities_with_member_count to authenticated;

grant delete, insert, references, select, trigger, truncate, update on communities_with_member_count to service_role;

