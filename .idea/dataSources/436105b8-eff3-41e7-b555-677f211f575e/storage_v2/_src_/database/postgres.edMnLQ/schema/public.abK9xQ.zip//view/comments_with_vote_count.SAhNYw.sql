create view comments_with_vote_count
            (id, user_id, post_id, content, is_deleted, parent_comment_id, created_at, updated_at, vote_count) as
SELECT comments.id,
       comments.user_id,
       comments.post_id,
       comments.content,
       comments.is_deleted,
       comments.parent_comment_id,
       comments.created_at,
       comments.updated_at,
       sum(
               CASE
                   WHEN comment_votes.is_upvote = true THEN 1
                   WHEN comment_votes.is_upvote = false THEN '-1'::integer
                   ELSE 0
                   END) AS vote_count
FROM comments
         LEFT JOIN comment_votes ON comments.id = comment_votes.comment_id
GROUP BY comments.id;

alter table comments_with_vote_count
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on comments_with_vote_count to anon;

grant delete, insert, references, select, trigger, truncate, update on comments_with_vote_count to authenticated;

grant delete, insert, references, select, trigger, truncate, update on comments_with_vote_count to service_role;

