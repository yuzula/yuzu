create view posts_with_hotness
            (id, user_id, community_domain_name, content, is_private, is_deleted, created_at, updated_at, vote_count,
             comment_count, hotness)
as
SELECT posts_with_vote_and_comment_count.id,
       posts_with_vote_and_comment_count.user_id,
       posts_with_vote_and_comment_count.community_domain_name,
       posts_with_vote_and_comment_count.content,
       posts_with_vote_and_comment_count.is_private,
       posts_with_vote_and_comment_count.is_deleted,
       posts_with_vote_and_comment_count.created_at,
       posts_with_vote_and_comment_count.updated_at,
       posts_with_vote_and_comment_count.vote_count,
       posts_with_vote_and_comment_count.comment_count,
       (posts_with_vote_and_comment_count.vote_count - 1)::numeric /
       (((EXTRACT(epoch FROM CURRENT_TIMESTAMP) - EXTRACT(epoch FROM posts_with_vote_and_comment_count.created_at)) /
         3600::numeric + 2::numeric) ^ 1.5) AS hotness
FROM posts_with_vote_and_comment_count;

alter table posts_with_hotness
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on posts_with_hotness to anon;

grant delete, insert, references, select, trigger, truncate, update on posts_with_hotness to authenticated;

grant delete, insert, references, select, trigger, truncate, update on posts_with_hotness to service_role;

