create function count_comments_by_user(comment_user_id uuid) returns integer
    stable
    language sql
as
$$
  select coalesce(count(id), 0)
  from comments
  where user_id = comment_user_id;
$$;

alter function count_comments_by_user(uuid) owner to postgres;

grant execute on function count_comments_by_user(uuid) to anon;

grant execute on function count_comments_by_user(uuid) to authenticated;

grant execute on function count_comments_by_user(uuid) to service_role;

