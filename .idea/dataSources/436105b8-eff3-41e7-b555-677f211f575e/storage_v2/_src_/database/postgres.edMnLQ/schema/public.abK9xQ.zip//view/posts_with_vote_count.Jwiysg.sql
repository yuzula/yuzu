create view posts_with_vote_count
            (id, user_id, community_domain_name, content, is_private, is_deleted, created_at, updated_at, vote_count) as
SELECT posts.id,
       posts.user_id,
       posts.community_domain_name,
       posts.content,
       posts.is_private,
       posts.is_deleted,
       posts.created_at,
       posts.updated_at,
       sum(
               CASE
                   WHEN post_votes.is_upvote = true THEN 1
                   WHEN post_votes.is_upvote = false THEN '-1'::integer
                   ELSE 0
                   END) AS vote_count
FROM posts
         LEFT JOIN post_votes ON posts.id = post_votes.post_id
GROUP BY posts.id;

alter table posts_with_vote_count
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on posts_with_vote_count to anon;

grant delete, insert, references, select, trigger, truncate, update on posts_with_vote_count to authenticated;

grant delete, insert, references, select, trigger, truncate, update on posts_with_vote_count to service_role;

