create function count_community_members(domain_name text) returns integer
    stable
    language sql
as
$$
  select count(id)
  from profiles
  where community_domain_name = domain_name;
$$;

alter function count_community_members(text) owner to postgres;

grant execute on function count_community_members(text) to anon;

grant execute on function count_community_members(text) to authenticated;

grant execute on function count_community_members(text) to service_role;

