create view posts_with_vote_and_comment_count
            (id, user_id, community_domain_name, content, is_private, is_deleted, created_at, updated_at, vote_count,
             comment_count)
as
SELECT posts_with_vote_count.id,
       posts_with_vote_count.user_id,
       posts_with_vote_count.community_domain_name,
       posts_with_vote_count.content,
       posts_with_vote_count.is_private,
       posts_with_vote_count.is_deleted,
       posts_with_vote_count.created_at,
       posts_with_vote_count.updated_at,
       posts_with_vote_count.vote_count,
       posts_with_comment_count.comment_count
FROM posts_with_vote_count
         JOIN posts_with_comment_count ON posts_with_vote_count.id = posts_with_comment_count.id;

alter table posts_with_vote_and_comment_count
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on posts_with_vote_and_comment_count to anon;

grant delete, insert, references, select, trigger, truncate, update on posts_with_vote_and_comment_count to authenticated;

grant delete, insert, references, select, trigger, truncate, update on posts_with_vote_and_comment_count to service_role;

