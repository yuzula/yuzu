create view posts_with_comment_count
            (id, user_id, community_domain_name, content, is_private, is_deleted, created_at, updated_at,
             comment_count) as
SELECT posts.id,
       posts.user_id,
       posts.community_domain_name,
       posts.content,
       posts.is_private,
       posts.is_deleted,
       posts.created_at,
       posts.updated_at,
       count(comments.id) AS comment_count
FROM posts
         LEFT JOIN comments ON posts.id = comments.post_id
GROUP BY posts.id;

alter table posts_with_comment_count
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on posts_with_comment_count to anon;

grant delete, insert, references, select, trigger, truncate, update on posts_with_comment_count to authenticated;

grant delete, insert, references, select, trigger, truncate, update on posts_with_comment_count to service_role;

