create view posts_with_hotness_with_flagged
            (id, user_id, community_domain_name, content, is_private, is_deleted, created_at, updated_at, vote_count,
             comment_count, hotness, is_flagged)
as
SELECT posts_with_hotness.id,
       posts_with_hotness.user_id,
       posts_with_hotness.community_domain_name,
       posts_with_hotness.content,
       posts_with_hotness.is_private,
       posts_with_hotness.is_deleted,
       posts_with_hotness.created_at,
       posts_with_hotness.updated_at,
       posts_with_hotness.vote_count,
       posts_with_hotness.comment_count,
       posts_with_hotness.hotness,
       COALESCE(reported_posts.is_flagged, false) AS is_flagged
FROM posts_with_hotness
         LEFT JOIN reported_posts ON posts_with_hotness.id = reported_posts.post_id;

alter table posts_with_hotness_with_flagged
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on posts_with_hotness_with_flagged to anon;

grant delete, insert, references, select, trigger, truncate, update on posts_with_hotness_with_flagged to authenticated;

grant delete, insert, references, select, trigger, truncate, update on posts_with_hotness_with_flagged to service_role;

