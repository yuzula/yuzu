create view post_screen_comments
            (id, user_id, post_id, content, is_deleted, parent_comment_id, created_at, updated_at, vote_count,
             is_flagged, current_user_vote, username)
as
SELECT comments_with_vote_count.id,
       comments_with_vote_count.user_id,
       comments_with_vote_count.post_id,
       comments_with_vote_count.content,
       comments_with_vote_count.is_deleted,
       comments_with_vote_count.parent_comment_id,
       comments_with_vote_count.created_at,
       comments_with_vote_count.updated_at,
       comments_with_vote_count.vote_count,
       COALESCE(reported_comments.is_flagged, false) AS is_flagged,
       CASE
           WHEN comment_votes.is_upvote = true THEN 'upvote'::text
           WHEN comment_votes.is_upvote = false THEN 'downvote'::text
           ELSE NULL::text
           END                                       AS current_user_vote,
       profiles.username
FROM comments_with_vote_count
         LEFT JOIN reported_comments ON comments_with_vote_count.id = reported_comments.comment_id
         LEFT JOIN comment_votes
                   ON comments_with_vote_count.id = comment_votes.comment_id AND auth.uid() = comment_votes.user_id
         JOIN profiles ON comments_with_vote_count.user_id = profiles.id;

alter table post_screen_comments
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on post_screen_comments to anon;

grant delete, insert, references, select, trigger, truncate, update on post_screen_comments to authenticated;

grant delete, insert, references, select, trigger, truncate, update on post_screen_comments to service_role;

